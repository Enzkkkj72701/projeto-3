import type { Metadata, Viewport } from "next";
import { Fredoka, Nunito } from "next/font/google";
import "./globals.css";

// Título: Fredoka (encorpada, arredondada, amigável).
const fredoka = Fredoka({
  subsets: ["latin"],
  weight: ["500", "600", "700"],
  variable: "--font-fredoka",
  display: "swap",
});

// Texto corrido: Nunito (legível e neutra).
const nunito = Nunito({
  subsets: ["latin"],
  weight: ["400", "600", "700"],
  variable: "--font-nunito",
  display: "swap",
});

export const metadata: Metadata = {
  title: "GoPet Petshop | Banho e tosa com hora marcada em Anápolis-GO",
  description:
    "Banho, tosa, ração e acessórios para cães e gatos no Maracanã, em Anápolis-GO. Nota 4,8/5 em cerca de 70 avaliações. Agende pelo WhatsApp, com hora marcada.",
  openGraph: {
    title: "GoPet Petshop | Banho e tosa com hora marcada em Anápolis-GO",
    description:
      "Chama no WhatsApp, combina o horário e leva seu cão ou gato. Av. Universitária, 308, Maracanã.",
    locale: "pt_BR",
    type: "website",
  },
};

export const viewport: Viewport = {
  themeColor: "#ff6000",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="pt-BR" className={`${fredoka.variable} ${nunito.variable}`}>
      <body className="antialiased">{children}</body>
    </html>
  );
}
