import Image from "next/image";
import WhatsAppButton from "@/components/WhatsAppButton";

// Server Component: página 100% estática, sem menu mobile nem estado, então nenhum Client Component é necessário.

const ENDERECO = "Av. Universitária, nº 308, Maracanã, Anápolis - GO, 75040-080";
const CONSULTA_MAPA = "GoPet Petshop, Av. Universitária, 308, Maracanã, Anápolis - GO, 75040-080";
// Links para abrir o endereço e traçar a rota no Google Maps (sem mapa incorporado).
const MAPA_LINK = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(CONSULTA_MAPA)}`;
const ROTA_LINK = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(CONSULTA_MAPA)}`;

const MSG_TOPO = "Olá! Quero agendar banho e tosa para meu pet";
const MSG_PROVA = "Olá! Vi as avaliações da GoPet e quero agendar um horário para meu pet";
const MSG_AGENDAMENTO = "Olá! Quero combinar um horário de banho e tosa para meu pet";
const MSG_PRODUTOS = "Olá! Quero saber sobre ração e acessórios disponíveis";
const MSG_LOCAL = "Olá! Moro perto da GoPet e quero agendar banho e tosa";
const MSG_FECHAMENTO = "Olá! Vou levar meu pet na GoPet, pode separar o horário certinho?";

function Foto({
  src,
  alt,
  width,
  height,
  className = "",
  priority = false,
}: {
  src: string;
  alt: string;
  width: number;
  height: number;
  className?: string;
  priority?: boolean;
}) {
  return (
    <figure className={`relative ${className}`}>
      <Image
        src={src}
        alt={alt}
        width={width}
        height={height}
        priority={priority}
        sizes="(min-width: 768px) 33vw, 50vw"
        className="h-full w-full rounded-3xl object-cover"
      />
      {/* degradê suave embaixo da foto */}
      <div className="pointer-events-none absolute inset-0 rounded-3xl bg-linear-to-t from-marrom/45 to-transparent to-45%" />
    </figure>
  );
}

export default function Home() {
  return (
    <main>
      {/* 1. DOBRA PRINCIPAL */}
      <section className="bg-linear-to-br from-laranja via-[#ff8a1f] to-amarelo text-escuro">
        <div className="mx-auto max-w-5xl px-5 pb-14 pt-6 md:pb-20">
          <p className="inline-block rounded-full bg-pessego px-4 py-1 text-sm font-bold">
            Petshop no Maracanã · Anápolis-GO
          </p>
          <div className="mt-5 flex items-center gap-4">
            <Image
              src="/fotos/logo-gopet.jpg"
              alt="Logo da GoPet Petshop"
              width={112}
              height={112}
              priority
              className="h-[4.5rem] w-[4.5rem] flex-none rounded-2xl shadow-lg md:h-28 md:w-28"
            />
            <h1 className="text-5xl font-bold leading-[1.05] md:text-7xl">
              GoPet Petshop
            </h1>
          </div>
          <p className="mt-4 max-w-2xl text-xl font-semibold md:text-2xl">
            Agende banho e tosa para seu cão ou gato sem enrolação: você chama
            no WhatsApp, escolhe o horário e o pet é atendido na hora marcada.
          </p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
            <WhatsAppButton mensagem={MSG_TOPO} variante="marrom" className="w-full sm:w-auto">
              Agendar banho e tosa no WhatsApp
            </WhatsAppButton>
            <p className="text-sm font-semibold">
              Chama no WhatsApp pra confirmar o horário de hoje.
            </p>
          </div>
        </div>
      </section>

      {/* 2. PROVA ANTES DO PEDIDO */}
      <section className="mx-auto max-w-5xl px-5 py-12 md:py-16">
        <div className="flex flex-col items-start gap-6 rounded-3xl border-2 border-marrom g-nota p-6 md:flex-row md:items-center md:p-8">
          <p className="font-[family-name:var(--font-titulo)] text-6xl font-bold md:text-7xl">
            4,8<span className="text-3xl">/5</span>
          </p>
          <div>
            <p className="text-xl font-bold">
              Nota 4,8 de 5 em cerca de 70 avaliações públicas
            </p>
            <p className="mt-1 text-lg">
              Quem já levou o pet reconhece o cuidado e o atendimento atencioso.
              Aqui você vê o espaço e os bichos atendidos, sem precisar
              adivinhar.
            </p>
          </div>
        </div>

        <h2 className="mt-12 text-3xl font-bold md:text-4xl">
          Seu pet não fica trancado esperando a vez
        </h2>
        <p className="mt-3 max-w-3xl text-lg">
          O maior medo de quem leva o bichinho para a tosa é ele se machucar ou
          ser maltratado. Por isso a tosa aqui é feita por tosador experiente, com
          hora marcada, e o espaço de banho e tosa aparece nas fotos abaixo. Se
          quiser ver mais antes de decidir, é só pedir pelo WhatsApp.
        </p>

        {/* Fotos reais (recortadas dos posts do Instagram da GoPet, sem as bordas do app) */}
        <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-6">
          <Foto
            src="/fotos/espaco-tosa-bebe.jpg"
            alt="Cão shih-tzu com tosa bebê sobre a mesa de tosa da GoPet, com a loja ao fundo"
            width={1100}
            height={1451}
            className="col-span-2 md:col-span-3"
          />
          <Foto
            src="/fotos/banho-tosa-banner.jpg"
            alt="Cão shih-tzu recém-tosado com bandana, no espaço de banho e tosa da GoPet"
            width={1100}
            height={1356}
            className="col-span-2 md:col-span-3"
          />
          <Foto
            src="/fotos/pet-atendido-01.jpg"
            alt="Cão shih-tzu de pelo longo com laço xadrez, atendido na GoPet"
            width={1100}
            height={1246}
            className="md:col-span-2"
          />
          <Foto
            src="/fotos/pet-atendido-02.jpg"
            alt="Cão shih-tzu com laço vermelho de Natal, atendido na GoPet"
            width={1100}
            height={1246}
            className="md:col-span-2"
          />
          <Foto
            src="/fotos/pet-atendido-03.jpg"
            alt="Cãozinho com gravata xadrez verde, atendido na GoPet"
            width={1100}
            height={1246}
            className="col-span-2 md:col-span-2"
          />
        </div>

        <div className="mt-10">
          <WhatsAppButton mensagem={MSG_PROVA} className="w-full sm:w-auto">
            Quero agendar um horário
          </WhatsAppButton>
        </div>
      </section>

      {/* 3. SERVIÇOS */}
      <section className="g-servicos">
        <div className="mx-auto max-w-5xl px-5 py-12 md:py-16">
          <h2 className="text-3xl font-bold md:text-4xl">
            Banho, tosa, ração e acessórios no mesmo lugar
          </h2>
          <p className="mt-3 max-w-3xl text-lg">
            Dá pra resolver tudo numa ida só: deixa o pet limpinho e ainda leva
            o que falta em casa.
          </p>

          <div className="mt-8 grid gap-5 md:grid-cols-2">
            <article className="rounded-3xl border-2 border-marrom g-card p-6">
              <h3 className="text-2xl font-bold">Banho</h3>
              <p className="mt-2 text-lg">
                Banho para cães e gatos com hora marcada. Para manter o pelo e a
                pele em dia, muita gente volta a cada 15 ou 30 dias, e a gente
                te lembra disso pelo WhatsApp se você quiser.
              </p>
            </article>
            <article className="rounded-3xl border-2 border-marrom g-card p-6">
              <h3 className="text-2xl font-bold">Tosa</h3>
              <p className="mt-2 text-lg">
                Tosa feita com calma, no horário combinado, para o pet não ficar
                esperando. O retorno costuma ser a cada 15 ou 30 dias, conforme
                o pelo de cada bicho.
              </p>
            </article>
            <article className="rounded-3xl border-2 border-marrom g-card p-6">
              <h3 className="text-2xl font-bold">Ração</h3>
              <p className="mt-2 text-lg">
                Ração para cães e gatos na loja física. Pergunte pelo WhatsApp
                se o que o seu pet come está disponível.
              </p>
            </article>
            <article className="rounded-3xl border-2 border-marrom g-card p-6">
              <h3 className="text-2xl font-bold">Acessórios</h3>
              <p className="mt-2 text-lg">
                Variedade de acessórios para o dia a dia do pet. Dá para olhar
                de perto na loja e levar junto com o banho.
              </p>
            </article>
          </div>
        </div>
      </section>

      {/* 4. COMO FUNCIONA O AGENDAMENTO */}
      <section className="mx-auto max-w-5xl px-5 py-12 md:py-16">
        <h2 className="text-3xl font-bold md:text-4xl">
          Como agendar: três passos
        </h2>
        <ol className="mt-8 grid gap-5 md:grid-cols-3">
          {[
            {
              n: "1",
              t: "Chama no WhatsApp",
              d: "Conta se é cão ou gato e se quer banho, tosa ou os dois.",
            },
            {
              n: "2",
              t: "Combina o horário",
              d: "A gente escolhe com você o melhor horário e deixa reservado.",
            },
            {
              n: "3",
              t: "Leva o pet",
              d: "Chegou na hora marcada, o pet é atendido. Aqui não é chegar e ficar esperando.",
            },
          ].map((p) => (
            <li
              key={p.n}
              className="rounded-3xl border-2 border-marrom g-card-amarelo p-6"
            >
              <span className="flex h-11 w-11 items-center justify-center rounded-full bg-marrom text-xl font-bold text-amarelo">
                {p.n}
              </span>
              <h3 className="mt-4 text-2xl font-bold">{p.t}</h3>
              <p className="mt-2 text-lg">{p.d}</p>
            </li>
          ))}
        </ol>

        <p className="mt-8 max-w-3xl rounded-3xl g-nota p-5 text-lg font-semibold">
          Vai passar perto da hora de fechar? Manda um oi antes, que a gente dá
          um jeito de encaixar o seu pet sem correria.
        </p>

        <div className="mt-8">
          <WhatsAppButton mensagem={MSG_AGENDAMENTO} className="w-full sm:w-auto">
            Combinar meu horário
          </WhatsAppButton>
        </div>
      </section>

      {/* 5. PRODUTOS */}
      <section className="g-produtos">
        <div className="mx-auto max-w-5xl px-5 py-12 md:py-16">
          <h2 className="text-3xl font-bold md:text-4xl">
            Ração e acessórios na loja
          </h2>
          <p className="mt-3 max-w-3xl text-lg">
            A loja física tem ração e acessórios para cães e gatos. O estoque
            muda, então o jeito mais rápido de saber se tem o que você procura é
            perguntar pelo WhatsApp, antes de sair de casa.
          </p>
          <div className="mt-8">
            <WhatsAppButton mensagem={MSG_PRODUTOS} variante="marrom" className="w-full sm:w-auto">
              Perguntar sobre ração e acessórios
            </WhatsAppButton>
          </div>
        </div>
      </section>

      {/* 6. LOCALIZAÇÃO */}
      <section className="mx-auto max-w-5xl px-5 py-12 md:py-16">
        <h2 className="text-3xl font-bold md:text-4xl">
          No bairro Maracanã, em Anápolis
        </h2>
        <p className="mt-3 max-w-3xl text-lg">
          A GoPet fica na Av. Universitária, no Maracanã. Quem mora no bairro ou
          por perto leva o pet sem atravessar a cidade.
        </p>
        <p className="mt-4 text-lg">
          Chama no WhatsApp pra confirmar o horário de hoje.
        </p>

        <div className="g-local mt-6 flex flex-col gap-6 rounded-3xl border-2 border-marrom p-6 md:flex-row md:items-center md:justify-between md:p-8">
          <div className="flex items-start gap-4">
            <svg
              aria-hidden="true"
              viewBox="0 0 24 24"
              className="h-12 w-12 flex-none fill-marrom"
            >
              <path d="M12 2a7 7 0 0 0-7 7c0 5.25 7 13 7 13s7-7.75 7-13a7 7 0 0 0-7-7Zm0 9.5A2.5 2.5 0 1 1 12 6.5a2.5 2.5 0 0 1 0 5Z" />
            </svg>
            <address className="text-2xl font-bold not-italic leading-snug">
              Av. Universitária, nº 308
              <span className="block text-lg font-semibold">
                Maracanã · Anápolis - GO · CEP 75040-080
              </span>
            </address>
          </div>
          <div className="flex flex-col gap-3 sm:flex-row">
            <a
              href={MAPA_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="g-btn-marrom inline-flex items-center justify-center rounded-full border-2 border-marrom px-7 py-4 text-lg font-bold text-amarelo shadow-[0_4px_0_0_var(--color-marrom)]"
            >
              Abrir no Google Maps
            </a>
            <a
              href={ROTA_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="g-btn-amarelo inline-flex items-center justify-center rounded-full border-2 border-marrom px-7 py-4 text-lg font-bold text-marrom shadow-[0_4px_0_0_var(--color-marrom)]"
            >
              Como chegar
            </a>
          </div>
        </div>

        <div className="mt-8">
          <WhatsAppButton mensagem={MSG_LOCAL} className="w-full sm:w-auto">
            Moro perto, quero agendar
          </WhatsAppButton>
        </div>
      </section>

      {/* 7. FECHAMENTO */}
      <section className="g-fim text-white">
        <div className="mx-auto max-w-5xl px-5 py-14 text-center md:py-20">
          <h2 className="text-3xl font-bold text-amarelo md:text-5xl">
            Chama antes de ir
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-xl">
            Assim a gente já separa o horário certinho pro seu pet, e ele é
            atendido sem espera.
          </p>
          <div className="mt-8">
            <WhatsAppButton mensagem={MSG_FECHAMENTO} className="w-full sm:w-auto">
              Chamar a GoPet no WhatsApp
            </WhatsAppButton>
          </div>
          <p className="mt-10 text-sm text-pessego">
            GoPet Petshop · {ENDERECO}
          </p>
        </div>
      </section>
    </main>
  );
}
