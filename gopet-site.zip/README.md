# GoPet Petshop — landing page

Página de conversão da GoPet Petshop (Anápolis-GO), feita com Next.js 15 (App Router) e Tailwind v4.
Tudo leva para o WhatsApp: (62) 99181-6996.

## Publicar pelo GitHub + Vercel (grátis)

1. **Criar o repositório no GitHub**
   - Entre em github.com, clique em **New repository**, dê o nome `gopet-petshop` e crie (pode ser privado).
   - Na página do repositório vazio, clique em **uploading an existing file** e arraste **todo o conteúdo desta pasta** (as pastas `app`, `components`, `public` e os arquivos `package.json`, `tsconfig.json`, `next.config.ts`, `postcss.config.mjs`, `.gitignore`, `README.md`). Clique em **Commit changes**.
   - Se preferir pelo terminal:
     ```bash
     git init
     git add .
     git commit -m "Landing page GoPet"
     git branch -M main
     git remote add origin https://github.com/SEU-USUARIO/gopet-petshop.git
     git push -u origin main
     ```

2. **Publicar na Vercel**
   - Entre em vercel.com com a conta do GitHub e clique em **Add New → Project**.
   - Escolha o repositório `gopet-petshop` e clique em **Deploy**. Não precisa mudar nenhuma configuração: a Vercel reconhece o Next.js sozinha.
   - Em cerca de 1 minuto o site fica no ar num endereço `https://gopet-petshop.vercel.app` (ou parecido).

3. **A cada mudança**: ao enviar uma alteração para o GitHub (branch `main`), a Vercel publica de novo automaticamente.

4. **Domínio próprio** (opcional): na Vercel, em **Settings → Domains**, adicione o domínio e siga as instruções de DNS.

## Rodar no computador

```bash
npm install
npm run dev      # http://localhost:3000
npm run build    # confere se compila antes de publicar
```

## O que editar

- `app/page.tsx`: textos, mensagens do WhatsApp e fotos da página.
- `app/layout.tsx`: título e descrição do site (aparecem no Google).
- `app/globals.css`: cores e degradês.
- `components/WhatsAppButton.tsx`: botão de WhatsApp (número em `NUMERO_WHATSAPP`).
- `public/fotos/`: fotos e logo. Para trocar uma foto, substitua o arquivo mantendo o mesmo nome.

## Pontos para conferir antes de divulgar

- Horário de funcionamento: não foi informado, então o site diz "chama no WhatsApp pra confirmar o horário de hoje".
- As fotos vieram dos posts do Instagram da própria GoPet.
