// Server Component: só monta um link, não precisa de JavaScript no navegador.

const NUMERO_WHATSAPP = "5562991816996";

type Props = {
  /** Mensagem já pronta que abre preenchida no WhatsApp. */
  mensagem: string;
  children: React.ReactNode;
  /** "amarelo" para fundos claros/pêssego; "marrom" para fundos amarelos. */
  variante?: "amarelo" | "marrom";
  className?: string;
};

export function linkWhatsApp(mensagem: string) {
  return `https://wa.me/${NUMERO_WHATSAPP}?text=${encodeURIComponent(mensagem)}`;
}

export default function WhatsAppButton({
  mensagem,
  children,
  variante = "amarelo",
  className = "",
}: Props) {
  const cores =
    variante === "amarelo"
      ? "g-btn-amarelo text-marrom border-marrom"
      : "g-btn-marrom text-amarelo border-marrom";

  return (
    <a
      href={linkWhatsApp(mensagem)}
      target="_blank"
      rel="noopener noreferrer"
      className={`inline-flex items-center justify-center gap-2 rounded-full border-2 px-7 py-4 text-lg font-bold shadow-[0_4px_0_0_var(--color-marrom)] transition active:translate-y-1 active:shadow-none hover:brightness-105 ${cores} ${className}`}
    >
      <svg
        aria-hidden="true"
        viewBox="0 0 24 24"
        className="h-6 w-6 fill-current"
      >
        <path d="M12.04 2a9.9 9.9 0 0 0-8.5 14.9L2 22l5.27-1.5A9.9 9.9 0 1 0 12.04 2Zm0 18.1a8.2 8.2 0 0 1-4.2-1.15l-.3-.18-3.13.89.9-3.05-.2-.31a8.2 8.2 0 1 1 6.93 3.8Zm4.5-6.14c-.25-.12-1.46-.72-1.69-.8-.23-.09-.39-.12-.56.12-.16.25-.64.8-.78.97-.14.16-.29.18-.54.06-.25-.12-1.05-.39-2-1.24-.74-.66-1.24-1.47-1.38-1.72-.15-.25-.02-.38.11-.5.11-.11.25-.29.37-.43.12-.15.16-.25.25-.41.08-.17.04-.31-.02-.43-.06-.12-.56-1.35-.77-1.85-.2-.48-.4-.42-.56-.42h-.47c-.16 0-.43.06-.66.31-.23.25-.86.84-.86 2.05s.88 2.38 1 2.55c.12.16 1.73 2.64 4.19 3.7.59.25 1.04.4 1.4.52.59.19 1.12.16 1.55.1.47-.07 1.46-.6 1.66-1.17.2-.58.2-1.07.14-1.17-.06-.1-.23-.16-.47-.29Z" />
      </svg>
      {children}
    </a>
  );
}
